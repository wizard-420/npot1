echo "welcome to Game Changer Honeypot"
echo " "
echo "Choose option"
echo "1. Honeypot with Advance Config port + Netdata"
echo "2. Wordpress honeypot"
read useroption


case $useroption in

  1)
echo " "
    echo " "
netdata -p 5555
echo ""
   sudo ./Gamechanger.rb

    ;;

  2)
    echo -n "wordpot" 
    echo " "
   cd wordpot
ls
sudo python wordpot.py
    ;;

  *)
    echo -n "unknown" 
    echo " "
    ;;
esac
